/*
 * Real userland helloworld
 */

#include "tests/lib.h"

int main(void)
{
  puts("Hello, World!\n");
  return 0;
}
